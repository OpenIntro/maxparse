<?php 
   unlink('uploads/'.$_GET['file']);
?>